# AURORA Architecture

## v0.1 component boundaries

### Hypothesis layer
Creates explicit, inspectable hypotheses and strategies.

### Experiment layer
Turns a hypothesis into a deterministic experiment and executes a toy environment.

### Evidence layer
Converts observations into claims with provenance.

### Evaluation layer
Independently scores observations using transparent heuristics.

### Memory layer
Persists research artifacts as JSON. Human-readable storage makes audit and debugging easy.

### Controller
Coordinates the loop without hiding decisions behind an opaque framework.

## Why the environment is synthetic

AURORA v0.1 is intended to prove the architecture and reproducibility contract before adding external models or expensive datasets. The toy environment has a known hidden optimum, making it possible to test whether the research loop can discover and prefer a better strategy.

## Planned upgrades

- statistical significance and confidence intervals
- independent replication
- richer hypothesis mutation
- graph-based scientific memory
- model adapters
- tool-use sandbox
- adversarial evaluator
- benchmark suite
- cost/latency accounting
- experiment scheduling
