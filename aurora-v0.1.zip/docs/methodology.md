# Methodology

AURORA v0.1 treats a research cycle as:

1. Select a hypothesis.
2. Design a reproducible experiment.
3. Execute under a fixed seed.
4. Record observations.
5. Derive evidence with provenance.
6. Evaluate the result independently.
7. Persist the complete trace.
8. Select the next experiment.

The current evaluator is deliberately heuristic and should **not** be interpreted as statistical proof. A research-grade extension must add replication, uncertainty estimates, multiple-comparison controls where appropriate, and predefined acceptance criteria.
