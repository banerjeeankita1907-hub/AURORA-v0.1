# AURORA v0.1

**Autonomous Research, Optimization & Reliability Architecture**

AURORA v0.1 is a dependency-light research-agent kernel for running reproducible hypothesis → experiment → observation → evaluation loops.

> v0.1 is intentionally small. The architecture is designed to grow toward autonomous planning, scientific memory, verification, adversarial evaluation, and benchmark-driven research.

## What works now

- Structured research goals and hypotheses
- Deterministic experiment execution
- Persistent JSON research memory
- Evidence and provenance records
- Independent evaluation
- Basic research metrics
- Automatic next-hypothesis selection
- CLI for initializing and running a research session
- Unit tests
- No third-party runtime dependencies

## Requirements

Python 3.10+.

## Quick start

```bash
python -m aurora.cli init --goal "Improve a simulated optimization strategy"
python -m aurora.cli run --goal "Improve a simulated optimization strategy" --rounds 5
python -m aurora.cli status
python -m unittest discover -s tests -v
```

The default storage location is `.aurora/`.

You can override it:

```bash
python -m aurora.cli run --goal "..." --rounds 10 --store research.json
```

## Architecture

```text
Research Goal
      |
      v
Hypothesis Generator
      |
      v
Experiment Designer
      |
      v
Deterministic Executor
      |
      v
Observation + Evidence
      |
      v
Independent Evaluator
      |
      v
Research Memory
      |
      v
Next Hypothesis
      |
      +-------> repeat
```

## Design principles

1. **Reproducibility** — every experiment has a seed and recorded parameters.
2. **Provenance** — observations point back to experiments and hypotheses.
3. **Separation of concerns** — generation, execution, memory, and evaluation are distinct.
4. **No fake autonomy** — v0.1 uses transparent heuristics rather than claiming general intelligence.
5. **Upgradeable interfaces** — later model/API integrations can replace individual components.

## Project status

AURORA v0.1 is a foundation, not a finished autonomous scientist. The important next research layers are rigorous baselines, statistical evaluation, adaptive planning, richer memory, adversarial verification, and external-model integration.
