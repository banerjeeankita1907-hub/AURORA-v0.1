import tempfile
import unittest
from pathlib import Path

from aurora.core.controller import ResearchController
from aurora.memory.store import ResearchStore


class ControllerTests(unittest.TestCase):
    def test_run_creates_research_artifacts(self):
        with tempfile.TemporaryDirectory() as d:
            store = ResearchStore(Path(d) / "research.json")
            controller = ResearchController("Optimize a toy environment", store)
            results = controller.run(rounds=4, trials=8)
            self.assertEqual(len(results), 4)
            summary = store.summary()
            self.assertEqual(summary["experiments"], 4)
            self.assertEqual(summary["observations"], 4)
            self.assertEqual(summary["evaluations"], 4)


if __name__ == "__main__":
    unittest.main()
