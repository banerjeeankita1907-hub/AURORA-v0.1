import tempfile
import unittest
from pathlib import Path

from aurora.memory.store import ResearchStore


class StoreTests(unittest.TestCase):
    def test_round_trip(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "research.json"
            store = ResearchStore(path)
            store.set_goal("hello")
            store.append("hypotheses", {"id": "h1"})
            self.assertEqual(store.load()["goal"], "hello")
            self.assertEqual(store.load()["hypotheses"], [{"id": "h1"}])


if __name__ == "__main__":
    unittest.main()
