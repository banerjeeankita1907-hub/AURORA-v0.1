import unittest

from aurora.research.hypothesis import Hypothesis, seed_hypotheses


class HypothesisTests(unittest.TestCase):
    def test_seed_hypotheses_are_deterministic_ids(self):
        a = seed_hypotheses("test")
        b = seed_hypotheses("test")
        self.assertEqual([x.id for x in a], [x.id for x in b])
        self.assertEqual(len(a), 3)

    def test_factory(self):
        h = Hypothesis.create("g", "s", "moderate")
        self.assertEqual(h.goal, "g")
        self.assertEqual(h.strategy, "moderate")
        self.assertTrue(h.id.startswith("hyp_"))


if __name__ == "__main__":
    unittest.main()
