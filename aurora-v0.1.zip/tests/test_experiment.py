import unittest

from aurora.research.experiment import design_experiment, execute
from aurora.research.hypothesis import seed_hypotheses


class ExperimentTests(unittest.TestCase):
    def test_execution_is_reproducible(self):
        h = seed_hypotheses("goal")[0]
        e = design_experiment(h, seed=7, trials=10)
        a = execute(e)
        b = execute(e)
        self.assertEqual(a.scores, b.scores)
        self.assertEqual(a.mean, b.mean)

    def test_invalid_trials(self):
        h = seed_hypotheses("goal")[0]
        with self.assertRaises(ValueError):
            design_experiment(h, seed=1, trials=0)


if __name__ == "__main__":
    unittest.main()
