# Baseline experiment

The built-in v0.1 environment compares three fixed exploration strategies:

- conservative: 0.15
- moderate: 0.40
- aggressive: 0.75

The hidden optimum is approximately 0.42. The experiment is synthetic and exists to validate reproducible experimentation and selection—not to claim a real-world scientific discovery.
