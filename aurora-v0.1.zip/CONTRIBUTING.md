# Contributing

1. Keep components dependency-light where practical.
2. Add tests for behavioral changes.
3. Preserve reproducibility: experiments should record seeds and parameters.
4. Do not describe heuristic behavior as scientific proof.
5. Document assumptions and limitations.
