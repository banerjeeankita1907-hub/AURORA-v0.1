# Security

AURORA v0.1 does not execute arbitrary model-generated shell commands, access external networks, or handle credentials.

Future tool-execution features should use an explicit sandbox, least privilege, resource limits, allowlists, and audit logs.
