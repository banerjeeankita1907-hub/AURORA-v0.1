from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class ResearchState:
    goal: str
    round_index: int = 0
    active_hypothesis_id: str | None = None
    best_score: float | None = None
    history: list[dict[str, Any]] = field(default_factory=list)

    def record(self, entry: dict[str, Any]) -> None:
        self.history.append(entry)
        self.round_index += 1
        score = entry.get("evaluation", {}).get("score")
        if score is not None and (self.best_score is None or score > self.best_score):
            self.best_score = score

    def to_dict(self) -> dict[str, Any]:
        return {
            "goal": self.goal,
            "round_index": self.round_index,
            "active_hypothesis_id": self.active_hypothesis_id,
            "best_score": self.best_score,
            "history": self.history,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ResearchState":
        return cls(
            goal=data["goal"],
            round_index=data.get("round_index", 0),
            active_hypothesis_id=data.get("active_hypothesis_id"),
            best_score=data.get("best_score"),
            history=data.get("history", []),
        )
