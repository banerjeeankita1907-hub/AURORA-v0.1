from __future__ import annotations

from dataclasses import dataclass

from .controller import ResearchController
from ..memory.store import ResearchStore


@dataclass
class AuroraAgent:
    """Public high-level API for v0.1."""

    goal: str
    store_path: str = ".aurora/research.json"

    def run(self, rounds: int = 5, trials: int = 20):
        controller = ResearchController(self.goal, ResearchStore(self.store_path))
        return controller.run(rounds=rounds, trials=trials)

    def status(self):
        return ResearchStore(self.store_path).summary()
