from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ..evaluation.evaluator import Evaluation, evaluate
from ..memory.store import ResearchStore
from ..research.evidence import derive_evidence
from ..research.experiment import design_experiment, execute
from ..research.hypothesis import Hypothesis, seed_hypotheses


@dataclass
class ResearchController:
    goal: str
    store: ResearchStore

    def initialize(self) -> None:
        data = self.store.load()
        if data.get("goal") not in (None, self.goal):
            raise ValueError(
                f"Store already belongs to a different goal: {data.get('goal')!r}"
            )
        self.store.set_goal(self.goal)
        if not data.get("hypotheses"):
            for hypothesis in seed_hypotheses(self.goal):
                self.store.append("hypotheses", hypothesis.to_dict())

    def _hypotheses(self) -> list[Hypothesis]:
        data = self.store.load()
        return [Hypothesis(**h) for h in data.get("hypotheses", [])]

    def _baseline(self) -> float | None:
        data = self.store.load()
        scores = [
            x["score"]
            for x in data.get("evaluations", [])
            if x.get("accepted")
        ]
        return min(scores) if scores else None

    def choose_hypothesis(self, round_index: int) -> Hypothesis:
        hypotheses = self._hypotheses()
        if not hypotheses:
            raise RuntimeError("No hypotheses available")

        # Explore different seed hypotheses first, then favor the best observed
        # strategy while preserving deterministic tie-breaking.
        data = self.store.load()
        evaluated_ids = {
            e.get("hypothesis_id")
            for e in data.get("experiment_links", [])
        }
        unexplored = [h for h in hypotheses if h.id not in evaluated_ids]
        if unexplored:
            return unexplored[round_index % len(unexplored)]

        scores: dict[str, list[float]] = {}
        for link in data.get("experiment_links", []):
            scores.setdefault(link["hypothesis_id"], []).append(link["score"])

        return max(
            hypotheses,
            key=lambda h: (
                sum(scores.get(h.id, [0.0])) / max(1, len(scores.get(h.id, []))),
                h.strategy,
            ),
        )

    def run_round(self, round_index: int, trials: int = 20) -> dict[str, Any]:
        hypothesis = self.choose_hypothesis(round_index)
        experiment = design_experiment(
            hypothesis,
            seed=1000 + round_index,
            trials=trials,
        )
        observation = execute(experiment)

        baseline = self._baseline()
        evidence = derive_evidence(observation, baseline)
        evaluation = evaluate(observation, evidence, baseline)

        self.store.append("experiments", experiment.to_dict())
        self.store.append("observations", observation.to_dict())
        self.store.append("evidence", evidence.to_dict())
        self.store.append("evaluations", evaluation.to_dict())

        data = self.store.load()
        data.setdefault("experiment_links", []).append(
            {
                "experiment_id": experiment.id,
                "hypothesis_id": hypothesis.id,
                "score": evaluation.score,
                "accepted": evaluation.accepted,
            }
        )
        self.store.save(data)

        return {
            "hypothesis": hypothesis.to_dict(),
            "experiment": experiment.to_dict(),
            "observation": observation.to_dict(),
            "evidence": evidence.to_dict(),
            "evaluation": evaluation.to_dict(),
        }

    def run(self, rounds: int = 5, trials: int = 20) -> list[dict[str, Any]]:
        if rounds < 1:
            raise ValueError("rounds must be >= 1")
        self.initialize()
        return [self.run_round(i, trials) for i in range(rounds)]
