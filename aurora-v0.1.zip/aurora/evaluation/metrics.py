from __future__ import annotations

from statistics import mean
from typing import Iterable


def improvement(current: float, baseline: float) -> float:
    return current - baseline


def relative_improvement(current: float, baseline: float) -> float:
    if baseline == 0:
        return float("inf") if current > 0 else 0.0
    return (current - baseline) / abs(baseline)


def research_efficiency(validated_discoveries: int, experimental_cost: float) -> float:
    if experimental_cost <= 0:
        return 0.0
    return validated_discoveries / experimental_cost


def false_progress_rate(claims_rejected: int, total_claims: int) -> float:
    if total_claims <= 0:
        return 0.0
    return claims_rejected / total_claims


def mean_score(scores: Iterable[float]) -> float:
    values = list(scores)
    if not values:
        raise ValueError("scores cannot be empty")
    return mean(values)
