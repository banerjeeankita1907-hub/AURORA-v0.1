from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

from ..research.experiment import Observation
from ..research.evidence import Evidence
from .metrics import relative_improvement


@dataclass(frozen=True)
class Evaluation:
    observation_id: str
    score: float
    improvement: float
    reproducibility: float
    accepted: bool
    reasons: list[str]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def evaluate(
    observation: Observation,
    evidence: Evidence,
    baseline_mean: float | None = None,
) -> Evaluation:
    baseline = observation.mean if baseline_mean is None else baseline_mean
    delta = observation.mean - baseline

    # A transparent v0.1 heuristic. Later versions should replace this with
    # statistical tests, confidence intervals, and independent replication.
    stability = max(0.0, min(1.0, 1.0 - observation.variance * 8.0))
    reproducibility = stability
    accepted = evidence.strength >= 0.5 and stability >= 0.5

    reasons = [
        f"mean={observation.mean:.4f}",
        f"variance={observation.variance:.6f}",
        f"evidence_strength={evidence.strength:.3f}",
        f"relative_change={relative_improvement(observation.mean, baseline):+.3f}",
    ]

    return Evaluation(
        observation_id=observation.id,
        score=observation.mean,
        improvement=delta,
        reproducibility=reproducibility,
        accepted=accepted,
        reasons=reasons,
    )
