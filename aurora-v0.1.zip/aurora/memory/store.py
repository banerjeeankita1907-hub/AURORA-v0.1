from __future__ import annotations

import json
from pathlib import Path
from typing import Any


class ResearchStore:
    """Small JSON-backed append/update store.

    The format is intentionally human-readable so experiments can be audited
    without requiring a database server.
    """

    def __init__(self, path: str | Path = ".aurora/research.json") -> None:
        self.path = Path(path)

    def load(self) -> dict[str, Any]:
        if not self.path.exists():
            return {
                "schema_version": 1,
                "goal": None,
                "hypotheses": [],
                "experiments": [],
                "observations": [],
                "evidence": [],
                "evaluations": [],
            }
        return json.loads(self.path.read_text(encoding="utf-8"))

    def save(self, data: dict[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temp = self.path.with_suffix(self.path.suffix + ".tmp")
        temp.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")
        temp.replace(self.path)

    def append(self, collection: str, item: dict[str, Any]) -> None:
        data = self.load()
        data.setdefault(collection, []).append(item)
        self.save(data)

    def set_goal(self, goal: str) -> None:
        data = self.load()
        data["goal"] = goal
        self.save(data)

    def summary(self) -> dict[str, Any]:
        data = self.load()
        return {
            "path": str(self.path),
            "goal": data.get("goal"),
            "hypotheses": len(data.get("hypotheses", [])),
            "experiments": len(data.get("experiments", [])),
            "observations": len(data.get("observations", [])),
            "evidence": len(data.get("evidence", [])),
            "evaluations": len(data.get("evaluations", [])),
        }
