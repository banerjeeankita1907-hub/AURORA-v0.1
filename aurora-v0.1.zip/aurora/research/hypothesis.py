from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import Any
import hashlib
import uuid


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def stable_id(prefix: str, *parts: str) -> str:
    raw = "|".join(parts).encode("utf-8")
    digest = hashlib.sha256(raw).hexdigest()[:12]
    return f"{prefix}_{digest}"


@dataclass(frozen=True)
class Hypothesis:
    id: str
    goal: str
    statement: str
    strategy: str
    expected_direction: str
    created_at: str
    parent_id: str | None = None
    prior_score: float | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def create(
        cls,
        goal: str,
        statement: str,
        strategy: str,
        expected_direction: str = "maximize",
        parent_id: str | None = None,
        prior_score: float | None = None,
    ) -> "Hypothesis":
        return cls(
            id=stable_id("hyp", goal, statement, strategy),
            goal=goal,
            statement=statement,
            strategy=strategy,
            expected_direction=expected_direction,
            created_at=utc_now(),
            parent_id=parent_id,
            prior_score=prior_score,
        )


def seed_hypotheses(goal: str) -> list[Hypothesis]:
    """Create transparent baseline hypotheses for a generic optimization task."""
    return [
        Hypothesis.create(
            goal,
            "A moderate exploration rate will outperform both extreme exploration and no exploration.",
            "moderate",
        ),
        Hypothesis.create(
            goal,
            "A conservative exploration rate will produce more stable progress.",
            "conservative",
        ),
        Hypothesis.create(
            goal,
            "An aggressive exploration rate may find improvements faster but with higher variance.",
            "aggressive",
        ),
    ]
