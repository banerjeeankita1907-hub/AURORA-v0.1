from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any
import random

from .hypothesis import Hypothesis, stable_id, utc_now


STRATEGIES = {
    "conservative": 0.15,
    "moderate": 0.40,
    "aggressive": 0.75,
}


@dataclass(frozen=True)
class Experiment:
    id: str
    hypothesis_id: str
    strategy: str
    seed: int
    trials: int
    created_at: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class Observation:
    id: str
    experiment_id: str
    hypothesis_id: str
    scores: list[float]
    mean: float
    variance: float
    best: float
    seed: int
    created_at: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def design_experiment(hypothesis: Hypothesis, seed: int, trials: int = 20) -> Experiment:
    if hypothesis.strategy not in STRATEGIES:
        raise ValueError(f"Unknown strategy: {hypothesis.strategy}")
    if trials < 1:
        raise ValueError("trials must be >= 1")
    return Experiment(
        id=stable_id("exp", hypothesis.id, str(seed), str(trials)),
        hypothesis_id=hypothesis.id,
        strategy=hypothesis.strategy,
        seed=seed,
        trials=trials,
        created_at=utc_now(),
    )


def execute(experiment: Experiment) -> Observation:
    """Run a deterministic toy environment.

    The environment has a hidden optimum around exploration=0.42.
    Noise is deterministic given the experiment seed.
    """
    rng = random.Random(experiment.seed)
    exploration = STRATEGIES[experiment.strategy]
    scores: list[float] = []

    for _ in range(experiment.trials):
        distance = abs(exploration - 0.42)
        signal = 1.0 - (distance * 1.8)
        noise = rng.gauss(0.0, 0.035 + exploration * 0.025)
        scores.append(max(0.0, min(1.0, signal + noise)))

    mean = sum(scores) / len(scores)
    variance = sum((x - mean) ** 2 for x in scores) / len(scores)
    return Observation(
        id=stable_id("obs", experiment.id),
        experiment_id=experiment.id,
        hypothesis_id=experiment.hypothesis_id,
        scores=scores,
        mean=mean,
        variance=variance,
        best=max(scores),
        seed=experiment.seed,
        created_at=utc_now(),
    )
