from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

from .hypothesis import stable_id, utc_now
from .experiment import Observation


@dataclass(frozen=True)
class Evidence:
    id: str
    observation_id: str
    claim: str
    strength: float
    provenance: list[str]
    created_at: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def derive_evidence(observation: Observation, baseline_mean: float | None = None) -> Evidence:
    if baseline_mean is None:
        strength = 0.5
        claim = f"Observed mean score was {observation.mean:.4f}."
    else:
        delta = observation.mean - baseline_mean
        strength = max(0.0, min(1.0, 0.5 + delta * 2.0))
        claim = (
            f"Observed mean score was {observation.mean:.4f}; "
            f"baseline difference was {delta:+.4f}."
        )

    return Evidence(
        id=stable_id("evidence", observation.id),
        observation_id=observation.id,
        claim=claim,
        strength=strength,
        provenance=[observation.experiment_id, observation.hypothesis_id],
        created_at=utc_now(),
    )
