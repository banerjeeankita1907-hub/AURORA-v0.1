from __future__ import annotations

import argparse
import json
from pathlib import Path

from .core.agent import AuroraAgent
from .memory.store import ResearchStore


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="aurora",
        description="AURORA v0.1 research-agent kernel",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    init = sub.add_parser("init", help="initialize a research store")
    init.add_argument("--goal", required=True)
    init.add_argument("--store", default=".aurora/research.json")

    run = sub.add_parser("run", help="run research rounds")
    run.add_argument("--goal", required=True)
    run.add_argument("--rounds", type=int, default=5)
    run.add_argument("--trials", type=int, default=20)
    run.add_argument("--store", default=".aurora/research.json")

    status = sub.add_parser("status", help="show store status")
    status.add_argument("--store", default=".aurora/research.json")

    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)

    if args.command == "init":
        agent = AuroraAgent(args.goal, args.store)
        controller = ResearchStore(args.store)
        data = controller.load()
        if data.get("goal") not in (None, args.goal):
            raise SystemExit("Store belongs to a different goal.")
        from .core.controller import ResearchController
        ResearchController(args.goal, controller).initialize()
        print(f"Initialized AURORA research store: {Path(args.store)}")
        return 0

    if args.command == "run":
        agent = AuroraAgent(args.goal, args.store)
        results = agent.run(args.rounds, args.trials)
        for result in results:
            evaluation = result["evaluation"]
            hypothesis = result["hypothesis"]
            print(
                f"round={result['experiment']['seed'] - 1000} "
                f"strategy={hypothesis['strategy']} "
                f"score={evaluation['score']:.4f} "
                f"accepted={evaluation['accepted']}"
            )
        return 0

    if args.command == "status":
        print(json.dumps(ResearchStore(args.store).summary(), indent=2))
        return 0

    return 1


if __name__ == "__main__":
    raise SystemExit(main())
